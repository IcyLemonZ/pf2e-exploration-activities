# pf2e-explorationActivities

Import the "Exploration Activities Request" macro from the PF2E Exploration Activities compendium. 

To request an Exploration Activity from a player/players, select them and run the macro. A popup will appear on their screen with a drop down for them to select an activity. The selected activity will be output to the chat and if an effect exists it will be applied to thier token.

To choose or assign an exploration activity, select a token and run the "Set Exploration Activity" macro, use the drop down to choose the activity and press select. the selection will be written to chat, and if an effect exists it will be applied.

![image](https://user-images.githubusercontent.com/73080231/130515815-aff62cec-d127-4308-89c3-5be7fe3fcf20.png)
